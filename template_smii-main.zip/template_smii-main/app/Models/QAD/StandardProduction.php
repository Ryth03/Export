<?php

namespace App\Models\QAD;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StandardProduction extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
}
